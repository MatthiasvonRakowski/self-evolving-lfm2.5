import evoagentx.workflow.operators as operator
import runs.seed42.train.lfm2_5_16k.bilevel.round_6.prompt as prompt_custom
from evoagentx.models.model_configs import LLMConfig
from evoagentx.benchmark.benchmark import Benchmark
from evoagentx.models.model_utils import create_llm_instance

class Workflow:
    def __init__(self, name: str, llm_config: LLMConfig, benchmark: Benchmark | None = None):
        self.name = name
        self.llm = create_llm_instance(llm_config)
        self.benchmark = benchmark
        self.custom = operator.Custom(self.llm)

    async def __call__(self, problem: str, **kwargs) -> str:
        # Step 1: Initial solution
        solution = await self.custom(
            input=problem,
            instruction=prompt_custom.SOLVE_MATH_PROMPT,
        )
        initial_response = solution["response"]

        # Step 2: Review and verify the solution
        review = await self.custom(
            input=f"Problem: {problem}\n\nProposed Solution:\n{initial_response}",
            instruction=prompt_custom.VERIFY_MATH_PROMPT,
        )
        verified_response = review["response"]

        # Step 3: Extract and confirm the final answer cleanly
        final = await self.custom(
            input=f"Problem: {problem}\n\nVerified Solution:\n{verified_response}",
            instruction=prompt_custom.EXTRACT_ANSWER_PROMPT,
        )
        return final["response"]
