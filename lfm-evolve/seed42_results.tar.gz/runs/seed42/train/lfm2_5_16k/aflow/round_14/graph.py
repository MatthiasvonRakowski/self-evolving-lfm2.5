import evoagentx.workflow.operators as operator
import runs.seed42.train.lfm2_5_16k.aflow.round_14.prompt as prompt_custom
from evoagentx.models.model_configs import LLMConfig
from evoagentx.benchmark.benchmark import Benchmark
from evoagentx.models.model_utils import create_llm_instance

class Workflow:
    def __init__(self, name: str, llm_config: LLMConfig, benchmark: Benchmark | None = None):
        self.name = name
        self.llm = create_llm_instance(llm_config)
        self.benchmark = benchmark
        self.custom = operator.Custom(self.llm)

    async def __call__(self, problem: str, **kwargs) -> str:
        solution = await self.custom(
            input=problem,
            instruction=prompt_custom.SOLVE_MATH_PROMPT,
        )
        verified = await self.custom(
            input=problem + f"\n\nPrevious solution:\n{solution['response']}",
            instruction=prompt_custom.VERIFY_MATH_PROMPT,
        )
        return verified["response"]
