import evoagentx.workflow.operators as operator
import runs.seed44.train.qwen3_1_7b_16k.aflow.round_20.prompt as prompt_custom
from evoagentx.models.model_configs import LLMConfig
from evoagentx.benchmark.benchmark import Benchmark
from evoagentx.models.model_utils import create_llm_instance

class Workflow:
    def __init__(self, name: str, llm_config: LLMConfig, benchmark: Benchmark | None = None):
        self.name = name
        self.llm = create_llm_instance(llm_config)
        self.benchmark = benchmark
        self.custom = operator.Custom(self.llm)

    async def __call__(self, problem: str, **kwargs) -> str:
        # Step 1: Classify the problem type and extract key numerical data
        classification = await self.custom(
            input=problem,
            instruction=prompt_custom.CLASSIFY_PROBLEM_PROMPT,
        )
        problem_type = classification["response"]

        # Step 2: Solve using the classified problem type and extracted numbers as context
        solution = await self.custom(
            input=f"Problem: {problem}\n\nProblem Analysis:\n{problem_type}",
            instruction=prompt_custom.SOLVE_WITH_STRATEGY_PROMPT,
        )
        return solution["response"]
