import evoagentx.workflow.operators as operator
import runs.seed44.train.lfm2_5_16k.aflow.round_15.prompt as prompt_custom
from evoagentx.models.model_configs import LLMConfig
from evoagentx.benchmark.benchmark import Benchmark
from evoagentx.models.model_utils import create_llm_instance

class Workflow:
    def __init__(self, name: str, llm_config: LLMConfig, benchmark: Benchmark | None = None):
        self.name = name
        self.llm = create_llm_instance(llm_config)
        self.benchmark = benchmark
        self.custom = operator.Custom(self.llm)

    async def __call__(self, problem: str, **kwargs) -> str:
        decomposed = await self.custom(
            input=problem,
            instruction=prompt_custom.DECOMPOSE_MATH_PROMPT,
        )
        
        solution = await self.custom(
            input=f"Problem: {problem}\n\nKey Facts and Structure:\n{decomposed['response']}",
            instruction=prompt_custom.SOLVE_MATH_PROMPT,
        )
        
        verified = await self.custom(
            input=f"Problem: {problem}\n\nProposed Solution:\n{solution['response']}",
            instruction=prompt_custom.VERIFY_MATH_PROMPT,
        )
        return verified["response"]
