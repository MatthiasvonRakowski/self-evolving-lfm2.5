import evoagentx.workflow.operators as operator
import runs.seed42.train.llama3_2_1b.aflow.round_6.prompt as prompt_custom
from evoagentx.models.model_configs import LLMConfig
from evoagentx.benchmark.benchmark import Benchmark
from evoagentx.models.model_utils import create_llm_instance

class Workflow:
    def __init__(self, name: str, llm_config: LLMConfig, benchmark: Benchmark | None = None):
        self.name = name
        self.llm = create_llm_instance(llm_config)
        self.benchmark = benchmark
        self.custom = operator.Custom(self.llm)

    async def __call__(self, problem: str, **kwargs) -> str:
        # Step 1: Initial solution
        solution = await self.custom(
            input=problem,
            instruction=prompt_custom.SOLVE_MATH_PROMPT,
        )
        initial_answer = solution["response"]

        # Step 2: Verify and correct the solution
        verified = await self.custom(
            input=f"Problem: {problem}\n\nProposed Solution:\n{initial_answer}",
            instruction=prompt_custom.VERIFY_MATH_PROMPT,
        )
        return verified["response"]
