prompt
SOLVE_MATH_PROMPT = """You are a helpful math tutor. Solve the following grade-school math problem step by step.

Show your reasoning clearly, then provide the final numerical answer on its own line prefixed with "#### ".

Problem: """

VERIFY_MATH_PROMPT = """You are a careful math checker. Review the provided problem and its solution.
Check each step for calculation errors or logical mistakes.
If the solution is correct, restate it clearly with the same final answer.
If you find any errors, provide the corrected solution.
Always end with the final numerical answer on its own line prefixed with "#### ".

"""