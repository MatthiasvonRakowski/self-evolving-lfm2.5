import evoagentx.workflow.operators as operator
import runs.seed45.train.qwen3_1_7b_16k.bilevel.round_4.prompt as prompt_custom
from evoagentx.models.model_configs import LLMConfig
from evoagentx.benchmark.benchmark import Benchmark
from evoagentx.models.model_utils import create_llm_instance

class Workflow:
    def __init__(self, name: str, llm_config: LLMConfig, benchmark: Benchmark | None = None):
        self.name = name
        self.llm = create_llm_instance(llm_config)
        self.benchmark = benchmark
        self.custom = operator.Custom(self.llm)

    async def __call__(self, problem: str, **kwargs) -> str:
        # Step 1: Initial solution - standard step-by-step
        initial = await self.custom(
            input=problem,
            instruction=prompt_custom.SOLVE_MATH_PROMPT,
        )
        initial_solution = initial["response"]

        # Step 2: Alternative solution using a different approach
        alternative = await self.custom(
            input=problem,
            instruction=prompt_custom.SOLVE_ALT_PROMPT,
        )
        alt_solution = alternative["response"]

        # Step 3: Review and synthesize both solutions to get final answer
        review = await self.custom(
            input=f"Problem: {problem}\n\nSolution A:\n{initial_solution}\n\nSolution B:\n{alt_solution}",
            instruction=prompt_custom.REVIEW_MATH_PROMPT,
        )
        return review["response"]
