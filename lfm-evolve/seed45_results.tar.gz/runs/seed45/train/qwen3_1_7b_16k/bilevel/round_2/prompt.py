prompt
SOLVE_MATH_PROMPT = """You are a helpful math tutor. Solve the following grade-school math problem step by step.

Show your reasoning clearly, then provide the final numerical answer on its own line prefixed with "#### ".

Problem: """

REVIEW_MATH_PROMPT = """You are a careful math checker. You are given a math problem and a proposed solution.

Your task:
1. Carefully verify each calculation step in the proposed solution.
2. If the solution is correct, restate it clearly with the final answer on its own line prefixed with "#### ".
3. If you find any errors, redo the solution from scratch step by step, and provide the corrected final answer on its own line prefixed with "#### ".

Make sure the final line of your response is in the format: #### <number>

"""