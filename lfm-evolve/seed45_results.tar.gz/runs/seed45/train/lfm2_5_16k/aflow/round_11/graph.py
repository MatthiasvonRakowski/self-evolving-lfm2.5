import evoagentx.workflow.operators as operator
import runs.seed45.train.lfm2_5_16k.aflow.round_11.prompt as prompt_custom
from evoagentx.models.model_configs import LLMConfig
from evoagentx.benchmark.benchmark import Benchmark
from evoagentx.models.model_utils import create_llm_instance

class Workflow:
    def __init__(self, name: str, llm_config: LLMConfig, benchmark: Benchmark | None = None):
        self.name = name
        self.llm = create_llm_instance(llm_config)
        self.benchmark = benchmark
        self.custom = operator.Custom(self.llm)

    async def __call__(self, problem: str, **kwargs) -> str:
        # First solution: standard step-by-step
        solution1 = await self.custom(
            input=problem,
            instruction=prompt_custom.SOLVE_MATH_PROMPT,
        )
        # Second solution: direct arithmetic approach
        solution2 = await self.custom(
            input=problem,
            instruction=prompt_custom.SOLVE_MATH_DIRECT_PROMPT,
        )
        # Ensemble: pick the most consistent answer
        ensemble = await self.custom(
            input=f"Problem: {problem}\nSolution A: {solution1['response']}\nSolution B: {solution2['response']}",
            instruction=prompt_custom.ENSEMBLE_PROMPT,
        )
        return ensemble["response"]
